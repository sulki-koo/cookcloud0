package cookcloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CookcloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(CookcloudApplication.class, args);
	}

}
